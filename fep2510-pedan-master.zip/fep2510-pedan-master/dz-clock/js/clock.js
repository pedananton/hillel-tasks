console.log('The script works');
