export class TodoItem {
  #text = "";
  #completed = false;

  // -- временный код, чтобы тесты прошли --
  text = this.#text;
  completed = this.#completed;
  // -- удалите его, когда приступите к работе --

  // get text() {
  //   напишите реализацию геттера из #text
  // }

  // set text(value) {
  //   напишите реализацию сеттера согласно тестам
  // }

  // get completed() {
  //   напишите реализацию геттера из #completed
  // }

  // set completed(value) {
  //   напишите реализацию сеттера согласно тестам
  // }
}
