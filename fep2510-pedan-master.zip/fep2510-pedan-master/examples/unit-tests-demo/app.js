import { max2 } from './src/index.js';

console.log('\n\n===== HELLO =====\n\n');
console.log('Calculating max(3, 4) ...');
console.log('The result is: ', max2(3, 4));
console.log('\n\n=====  BYE  =====\n\n');
