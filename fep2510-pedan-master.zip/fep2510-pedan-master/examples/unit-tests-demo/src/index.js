export * from "./max2.js";
