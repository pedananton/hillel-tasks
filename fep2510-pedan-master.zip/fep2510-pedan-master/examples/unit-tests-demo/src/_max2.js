/**
 * @param {number} a
 * @param {number} b
 * @returns {number}
 */
export function _max2(a, b) {
  return a > b ? a : b;
}
