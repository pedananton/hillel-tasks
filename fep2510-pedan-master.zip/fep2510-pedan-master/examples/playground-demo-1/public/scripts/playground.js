import {App} from "./App.js";

const playground = document.getElementById('playground');
const app = new App(playground);
window.app = app;
