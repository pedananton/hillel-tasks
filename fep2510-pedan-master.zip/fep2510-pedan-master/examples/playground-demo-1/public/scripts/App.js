export class App {
    /**
     * @param {HTMLCanvasElement} canvas
     */
    constructor(canvas) {
        this.canvas = canvas;
        this.canvas.width = this.canvas.offsetWidth;
        this.canvas.height = this.canvas.offsetHeight;

        this.context = canvas.getContext('2d');
        this.tool = 'pen';
        this.startX = 0;
        this.startY = 0;

        this.canvas.addEventListener('mousedown', this.onMouseDown);
        this.canvas.addEventListener('mousemove', this.onMouseMove);
        this.canvas.addEventListener('mouseup', this.onMouseUp);
    }

    select(tool) {
        this.tool = tool;
    }

    configure(property, value) {
        this.context[property] = value;
    }

    erase() {
        const {width, height} = this.canvas;
        this.context.clearRect(0, 0, width, height);
    }

    /***
     * @param {MouseEvent} e
     */
    onMouseDown = (e) => {
        this.startX = e.offsetX;
        this.startY = e.offsetY;
    };

    /***
     * @param {MouseEvent} e
     */
    onMouseMove = (e) => {
        if (e.buttons !== 1) {
            return;
        }

        if (this.tool === "pen") {
            this.context.beginPath();
            this.context.moveTo(this.startX, this.startY);
            this.context.lineTo(e.offsetX, e.offsetY);
            this.context.stroke();
            this.startX = e.offsetX;
            this.startY = e.offsetY;
        }
    };

    /***
     * @param {MouseEvent} e
     */
    onMouseUp = (e) => {
        switch (this.tool) {
            case "rect": {
                const x = this.startX;
                const y = this.startY;
                const width = e.offsetX - x;
                const height = e.offsetY - y;
                this.context.beginPath();
                this.context.rect(x, y, width, height);
                this.context.fill();
                this.context.stroke();
                break;
            };
            case "ellipse": {
                const x = (this.startX + e.offsetX) / 2;
                const y = (this.startY + e.offsetY) / 2;
                const rx = Math.abs(x - this.startX);
                const ry = Math.abs(y - this.startY);
                this.context.beginPath();
                this.context.ellipse(x, y, rx, ry, 0, 0, Math.PI * 2);
                this.context.fill();
                break;
            };
        }
    };
}
