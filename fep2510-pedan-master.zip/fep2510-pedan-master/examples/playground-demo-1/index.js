const express = require('express');
const app = express();

app.set('view engine', 'ejs');

app.use('/node_modules', express.static('node_modules'));

app.use(express.static('public'));

app.get('/playground/:room', (req, res) => {
  res.render('playground', {ROOM_ID: req.params.room});
});

app.use(function(req, res){
  res.status(404);

  if (req.accepts('html')) {
    res.render('404', { url: req.url });
  } else if (req.accepts('json')) {
    res.send({ error: 'Not found' });
  } else {
    res.type('txt').send('Not found');
  }
});

app.listen(8080);
